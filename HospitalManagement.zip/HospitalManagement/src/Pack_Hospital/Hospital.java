package Pack_Hospital;

public class Hospital {

        private int patientid;
        private String tablename,date;
        private String patientname, visitorName;

        private String disease;
        private String doctorsname;
        private double fees;

        //  Constructor
        public Hospital() {
            this.patientid = patientid;
            this.patientname = patientname;
            this.disease = disease;
            this.doctorsname = doctorsname;
            this.fees = fees;
        }
        // Getters and setters

        public int getPatientID() {
            return patientid;
        }

        public void setPatientID(int patientID) {
            this.patientid = patientID;
        }

        public String getTablename() {
            return tablename;
        }

        public void setTablename(String tablename) {
            this.tablename = tablename;
        }

        public String getPatientName() {
            return patientname;
        }

        public void setPatientName(String patientName) {
            this.patientname = patientName;
        }

        public String getVisitorName() {
            return visitorName;
        }

        public void setVisitorName(String visitorName) {
            this.visitorName = visitorName;
        }

        public String getDisease() {
            return disease;
        }

        public void setDisease(String disease) {
            this.disease = disease;
        }

        public String getDoctorName() {
            return doctorsname;
        }

        public void setDoctorName(String doctorName) {
            this.doctorsname = doctorName;
        }

        public double getFees() {
            return fees;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public void setFees() {
            this.fees = fees;
        }

        @Override
        public String toString() {
            return "Hospital{" +
                    "patientId=" + patientid +
                    ", patientName=" + patientname +
                    ", disease=" + disease +
                    ", doctorName=" + doctorsname +
                    ", fees=" + fees +
                    '}';
        }


    }

