package Pack_Hospital;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

import static java.lang.System.exit;

public class HospitalMain {
    public static void main(String[] args) throws SQLException, ParseException {
        HospitalController dbf = new HospitalController();
        String dbUrl = "jdbc:postgresql://localhost:5432/PROJECT1";
        String dbUser = "postgres";
        String dbPass = "Agresha@2012";
        Scanner sc = new Scanner(System.in);
        Connection connection = dbf.connect_db(dbUrl, dbUser, dbPass);
        int choice;
        char op;

        do {
            System.out.println("Enter your choice :");
            System.out.println("Enter 1 to create Hospital Table and Visitor table:");
            System.out.println("Enter 2 to insert Patient data :");
            System.out.println("Enter 3 to enter visiting details :");
            System.out.println("Enter 4 to find doctor :");
            System.out.println("Enter 5 to change doctor :");
            System.out.println("Enter 6 to find patient with same disease :");
            System.out.println("Enter 7 for fees discount :");
            System.out.println("Enter 8 to print all patients data : ");
            System.out.println("Enter 9 to print all visitors data : ");
            System.out.println("Enter 10 to exit : ");
            System.out.println("Enter your choice : ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    dbf.createTable(connection);
                    dbf.createTabletwo(connection);
                }

                case 2 -> dbf.insertPatient(connection);

                case 3 -> dbf.insertVisitor(connection);

                case 4 -> dbf.findDoctor(connection);

                case 5 -> dbf.changeDoctor(connection);

                case 6 -> dbf.findPatientwithSameDisease(connection);

                case 7 -> dbf.applyDiscount(connection);

                case 8 -> dbf.AllPatients(connection);

                case 9 -> dbf.displayAllVisitors(connection);

                case 10 -> exit(0);
            }

            System.out.println("Do you want to continue? (Y/N)");
            op = sc.next().charAt(0);
            while (op != 'Y' && op != 'y' && op != 'N' && op != 'n') {
                System.out.println("Enter Y for yes or N for no!");
                op = sc.next().charAt(0);
            }

        } while (op == 'y' || op == 'Y');
    }
}
