
    package Pack_Hospital;


import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

    public class HospitalController {
        int patientid;
        String tablename;
        String patientname, visitorName;
        String disease;
        String doctorsname;
        double fees;
        PreparedStatement prepStat;

        ResultSet resultSet;
        Hospital hospital = new Hospital();


        public Connection connect_db(String dbUrl, String dbUser, String dbPass) {
            Connection conn = null;
            try {
                conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                if (conn != null) {
                    System.out.println("Connection to DB established.");
                } else {
                    System.out.println("Connection to DB failed!");
                }
            } catch (SQLException e) {
                System.out.println("Error connecting to DB: " + e.getMessage());
            }
            return conn;
        }

        public void createTable(Connection conn) throws SQLException {

            prepStat = conn.prepareStatement("create table hospital(patientid SERIAL, patientname varchar(100) NOT NULL , disease varchar(100) NOT NULL , doctorname varchar(100) NOT NULL , fees double precision NOT NULL,  primary key(patientid))");
            prepStat.executeUpdate();
            System.out.println("Table is created...");


        }
        public void createTabletwo(Connection conn) throws SQLException {
            prepStat = conn.prepareStatement("CREATE TABLE visitor (visitorid SERIAL, patientid INT, patientname VARCHAR(100) NOT NULL, visit_date DATE, PRIMARY KEY(visitorid))");
            prepStat.executeUpdate();
            System.out.println("Table is created...");
        }

        public void insertPatient(Connection conn) throws SQLException {
            Scanner sc = new Scanner(System.in);
            Scanner sc1 = new Scanner(System.in);
            Scanner sc2 = new Scanner(System.in);
            Scanner sc3 = new Scanner(System.in);


            prepStat = conn.prepareStatement("insert into hospital (patientid,patientname,disease,doctorname,fees) values (?,?,?,?,?)");
            int size;
            System.out.println("How many patients do you want to enter : ");
            size=sc.nextInt();
            for (int i = 0; i <size ; i++) {

                System.out.println("Enter Patient Id : ");
                patientid = sc.nextInt();
                hospital.setPatientID(patientid);
                prepStat.setInt(1,patientid);

                System.out.println("Enter Patient Name : ");
                patientname = sc1.nextLine();
                hospital.setPatientName(patientname);
                prepStat.setString(2,patientname);

                System.out.println("Enter  Disease :  ");
                disease = sc2.next();
                hospital.setDisease(disease);
                prepStat.setString(3,disease);

                System.out.println("Enter Doctor's Name : ");
                doctorsname = sc3.nextLine();
                hospital.setDoctorName(doctorsname);
                prepStat.setString(4,doctorsname);

                System.out.println("Enter  Fees :");
                fees=sc.nextDouble();
                hospital.setFees();
                prepStat.setDouble(5,fees);

                prepStat.executeUpdate();
                System.out.println("Patient Created ");


            }
        }

        public void insertVisitor(Connection conn) throws SQLException, ParseException {
            Scanner sc = new Scanner(System.in);
            Scanner sc1 = new Scanner(System.in);
            Scanner sc4 = new Scanner(System.in);

            prepStat = conn.prepareStatement("INSERT INTO visitor (visitorid, patientid, patientname, visit_date) VALUES (?, ?, ?, ?)");
            int size;
            System.out.println("How many visitors do you want to enter : ");
            size = sc.nextInt();
            for (int i = 0; i < size; i++) {

                System.out.println("Enter visitor Id : ");
                int visitorid = sc.nextInt();
                prepStat.setInt(1, visitorid);

                System.out.println("Enter Patient Id : ");
                int patientid = sc.nextInt();
                prepStat.setInt(2, patientid);
                System.out.println("Enter Patient Name : ");
                String patientname = sc1.nextLine();
                prepStat.setString(3, patientname);

                System.out.println("Enter date in format (yyyy-MM-dd) :");
                String visitDateStr = sc4.nextLine();

                // Convert String to java.sql.Date
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                java.util.Date parsedDate = dateFormat.parse(visitDateStr);
                java.sql.Date visitDate = new java.sql.Date(parsedDate.getTime());

                prepStat.setDate(4, visitDate);

                prepStat.executeUpdate();
                System.out.println("Visitor Created ");
            }
        }


        public void findDoctor(Connection conn) throws SQLException {
            Scanner sc4=new Scanner(System.in);
            try {
                System.out.println("Enter doctor's name to find : ");
                String doctorName = sc4.nextLine();

                prepStat = conn.prepareStatement("SELECT * FROM hospital WHERE doctorname = ?");
                prepStat.setString(1, doctorName);
                resultSet = prepStat.executeQuery();

                while (resultSet.next()) {
                    System.out.println(resultSet.getInt("patientid") + " " +
                            resultSet.getString("patientname") + " " +
                            resultSet.getString("disease") + " " +
                            resultSet.getString("doctorname") + " " +
                            resultSet.getDouble("fees"));
                }
            } catch (SQLException e) {
                System.out.println("Error finding doctor: " + e.getMessage());
            }
        }

        public void findPatientwithSameDisease(Connection conn) throws SQLException {
            Scanner sc=new Scanner(System.in);
            try {
                System.out.println("Enter Disease : ");
                String disease = sc.nextLine();

                prepStat = conn.prepareStatement("SELECT * FROM hospital WHERE disease = ?");
                prepStat.setString(1, disease);
                resultSet = prepStat.executeQuery();

                while (resultSet.next()) {
                    System.out.println(resultSet.getInt("patientid") + " " +
                            resultSet.getString("patientname") + " " +
                            resultSet.getString("disease") + " " +
                            resultSet.getString("doctorname") + " " +
                            resultSet.getDouble("fees"));
                }
            } catch (SQLException e) {
                System.out.println("Error finding patients with the same disease: " + e.getMessage());
            }
        }

        public void applyDiscount(Connection conn) throws SQLException {
            Scanner sc = new Scanner(System.in);

            try {
                System.out.println("Enter Patient ID to apply discount: ");
                int patientId = sc.nextInt();

                System.out.println("Enter discount amount: ");
                double discount = sc.nextDouble();

                prepStat = conn.prepareStatement("UPDATE hospital SET fees = fees - ? WHERE patientid = ?");
                prepStat.setDouble(1, discount);
                prepStat.setInt(2, patientId);

                int affectedRows = prepStat.executeUpdate();

                if (affectedRows > 0) {
                    System.out.println("Discount applied successfully.");
                } else {
                    System.out.println("Patient not found with ID " + patientId);
                }
            } catch (SQLException e) {
                System.out.println("Error applying discount: " + e.getMessage());
            }
        }
        public void AllPatients(Connection conn) throws SQLException {
            try {
                String sql = "SELECT * FROM hospital";
                try (Statement statement = conn.createStatement();
                     ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        System.out.println("Patient ID: " + resultSet.getInt("patientid"));
                        System.out.println("Patient Name: " + resultSet.getString("patientname"));
                        System.out.println("Disease: " + resultSet.getString("disease"));
                        System.out.println("Doctor's Name: " + resultSet.getString("doctorname"));  // Adjust the column name here
                        System.out.println("Fees: " + resultSet.getDouble("fees"));
                        System.out.println("-----");
                    }
                }
            } catch (SQLException e) {
                System.out.println("Error displaying all patients: " + e.getMessage());
            }
        }

        public void displayAllVisitors(Connection conn) throws SQLException {
            try {
                prepStat = conn.prepareStatement("SELECT * FROM visitor");
                resultSet = prepStat.executeQuery();

                while (resultSet.next()) {
                    System.out.println("Visitor ID:"+resultSet.getInt("visitorid"));
                    System.out.println("Patient ID: " + resultSet.getInt("patientid"));
                    System.out.println("Patient Name: " + resultSet.getString("patientname"));
                    System.out.println("Visit Date : "+resultSet.getString("visit_date"));
                    System.out.println("-----");
                }
            } catch (SQLException e) {
                System.out.println("Error displaying all patients: " + e.getMessage());
            }
        }
        public void changeDoctor(Connection conn) throws SQLException {
            Scanner sc = new Scanner(System.in);
            Scanner sc1 = new Scanner(System.in);

            try {
                System.out.println("Enter patient ID: ");
                int patientId = sc.nextInt();

                System.out.println("Enter new doctor's name: ");
                String newDoctorName = sc1.nextLine();

                prepStat = conn.prepareStatement("UPDATE hospital SET doctorname = ? WHERE patientid = ?");
                prepStat.setString(1, newDoctorName);
                prepStat.setInt(2, patientId);

                int updatedRows = prepStat.executeUpdate();

                if (updatedRows > 0) {
                    System.out.println("Doctor changed successfully for patient ID " + patientId);
                } else {
                    System.out.println("Patient not found with ID " + patientId);
                }
            } catch (SQLException e) {
                System.out.println("Error changing doctor: " + e.getMessage());
            }
        }



    }

